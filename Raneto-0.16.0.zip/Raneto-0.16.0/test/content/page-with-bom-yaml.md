﻿---
Title: Example Page With BOM for YAML
Sort: 3
Modified: 2016-09-14T15:43:00-0500
---

This is some example content if a file that has a [BOM](https://en.wikipedia.org/wiki/Byte_order_mark) character.
