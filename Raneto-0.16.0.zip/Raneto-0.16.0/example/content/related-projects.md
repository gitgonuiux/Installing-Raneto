/*
Title: Related Projects
Sort: 9
*/

- [Deploy Raneto to your servers with Ansible](https://github.com/ryanlelek/raneto-devops) (@ryanlelek)
- [Run Raneto in a Vagrant container](https://github.com/draptik/vagrant-raneto) (@draptik)
