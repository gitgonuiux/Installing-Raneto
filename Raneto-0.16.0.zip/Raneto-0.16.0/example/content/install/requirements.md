/*
Title: Requirements
Sort: 1
*/

To run Raneto you need to have the following:

* [Node.js](http://nodejs.org) **v4.0.0** (or later)

Here are a [list of services](https://github.com/joyent/node/wiki/Node-Hosting) that provide Node hosting
if you are looking to publish your knowledgebase online.
