/*
Title: Deleting Pages
Sort: 3
*/

Deleting pages in Raneto is as simple as deleting the Markdown file (`.md`) from the content folder.
