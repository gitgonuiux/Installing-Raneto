/*
Title: Contributing to Raneto
Sort: 2
*/

Want to report a bug, request a feature, contribute or translate Raneto? At the moment most things can be
contributed via the main [Raneto GitHub repository](https://github.com/gilbitron/Raneto).

* [Submit a bug report](https://github.com/gilbitron/Raneto/issues?labels=bug)
* [Submit a feature request](https://github.com/gilbitron/Raneto/issues?labels=enhancement)
* [Submit a pull request](https://github.com/gilbitron/Raneto/pulls)
